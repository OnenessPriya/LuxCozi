<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\RetailerListOfOcc;
use App\Models\Activity;
use App\Models\Team;
use DB;
use Carbon\Carbon;
class UserController extends Controller
{
    
}
